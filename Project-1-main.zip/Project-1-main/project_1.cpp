#include<bits/stdc++.h>
#include<conio.h>
using namespace std;

int show_list()
{
	int choice;
	cout<<"\t\t ============================== \n";
	cout<<"\t\t ======Personal Portfolio====== \n";
	cout<<"\t\t ============================== \n";
	cout<<"\t\t 										 \n";
	cout<<"\t\t 1) Name \n";
	cout<<"\t\t 2) Bio \n";
	cout<<"\t\t 3) Programming Language \n";
	cout<<"\t\t 4) Hobbies \n";
	cout<<"\t\t 5) Exit \n";
	cout<<"\t\t ============================== \n";
	cout<<"\t\t Enter Your Choice : ";
	cin>>choice;
	if (choice <= 5 && choice > 0)
		return choice;
	else
		cout<<"Wrong choice!";
		return 0;
}

int main()
{
	int n = 1;
	system("color 0a");
	system("title Muhammad Ahsan");
	while( n!=0 )
	{
		system("cls");
		n = show_list();
		switch (n)
		{
			case 1:
				cout<<"\n\t\t ============================== \n";
				cout<<"\t\t Name: Muhammad Ahsan ";
				cout<<"\n\t\t ============================== \n";
				cout<<"\n\t\t Press Any key to Continue!";
				getch();
				break;
			case 2:
				cout<<"\n\t\t ======================================================================== \n";
				cout<<"\t\t My name is Muhammad Ahsan. I'm final year student of computer engineering. \n' ";
				cout<<"\t\t I'm certified Digital marketer nad also pyhton developer. \n' ";
				cout<<"\t\t ======================================================================== \n";
				cout<<"\n\t\t Press Any key to Continue!";
				getch();
				break;
			case 3:
				cout<<"\n\t\t ============================== \n";
				cout<<"\t\t Python";
				cout<<"\n\t\t ============================== \n";
				cout<<"\n\t\t Press Any key to Continue!";
				getch();
				break;
			case 4:
				cout<<"\n\t\t ============================== \n";
				cout<<"\t\t 1- Coding \n";
				cout<<"\t\t 2- Playing Chess ";
				cout<<"\n\t\t ============================== \n";
				cout<<"\n\t\t Press Any key to Continue!";
				getch();
				break;
			case 5:
				cout<<"\n\t\t Good Bye!\n";
				exit(0);
		}
	}
	
	cout<<n;
}
